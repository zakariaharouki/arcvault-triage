# ArcVault Intake & Triage (n8n + Groq)

An AI intake pipeline that classifies, enriches, routes and escalates inbound customer requests for the fictional B2B company "ArcVault". All tools used are free: n8n (self-hosted) and Groq's free tier.

| Deliverable | Where |
|---|---|
| Workflow (n8n export) | [`workflow/arcvault-triage.n8n.json`](workflow/arcvault-triage.n8n.json) |
| Structured output for the 5 samples | [`output/records.json`](output/records.json) |
| Prompt documentation | [`docs/PROMPTS.md`](docs/PROMPTS.md) |
| Architecture write-up | [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) |
| Screenshots / recording | [`docs/screenshots/`](docs/screenshots) · recording link: _TODO_ |

## Pipeline

`Webhook → Classify (LLM) → Validate → Enrich + summary (LLM) → Route & Escalate (code) → Human Review? → Deliver to queue → Return JSON`

- **Queues:** Engineering, Engineering On-Call, Product, Billing, Technical Support, and **Human Review** (escalation and fallback)
- **Escalation:** confidence < 0.70, Incident/Outage, critical phrases, billing discrepancy > $500, or invalid classification

## Run it locally

1. **Start n8n:** `npx n8n` and open http://localhost:5678
2. **Import:** Workflows → *Import from File* → `workflow/arcvault-triage.n8n.json`
3. **Groq credential:** create a free key at console.groq.com. In n8n go to *Credentials → New → Header Auth*: Name `Authorization`, Value `Bearer gsk_...`. Select it on **LLM: Classify** and **LLM: Enrich & Summarize**.
4. **Mock queue endpoint (optional):** open https://webhook.site, copy your unique URL and paste it into **Deliver: Escalation Queue** and **Deliver: Team Queue**. Records then appear there tagged with `?queue=`.
5. **Activate/Publish** the workflow, then run:
   ```bash
   node scripts/send-samples.mjs
   ```
   It posts the 5 sample messages and writes `output/records.json`.

## Development

```bash
python scripts/build-workflow.py   # rebuild workflow JSON from prompts/ and src/
node test/logic.test.mjs           # offline tests of validation/routing/escalation (10 cases)
```
Prompts (`prompts/`) and Code-node logic (`src/`) live as plain files and are compiled into the workflow, so they can be reviewed, diffed and tested without n8n.

## How I used AI

_TODO (Zakaria): fill in after running. Which tool built what, what you reviewed, and what the AI got wrong that you fixed (for example misclassifications on the real run, or nodes that didn't import cleanly)._
